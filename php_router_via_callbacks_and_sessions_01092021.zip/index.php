<?php
// header('Access-Control-Allow-Origin: *'); // remove this on prod !
include_once './funcs.php';
// -- front controller: ---------------- 

// $req = getRequest();

// http://localhost:8000
// dd($req);
/*
Array(
	[get_request] => Array()
    [post_request] => Array()
)
*/
// http://localhost:8000/?/
// dd($req) == .. [get_request] => Array([/] => ) ..

// http://localhost:8000/?route1
// dd($req) == .. [get_request] => Array([route1] => ) ..

app('', function() {

	$req = getRequest();
	
	if(empty($req['get_request']) || isset($req['get_request']['/'])) {
		render('/templates/home_vw');
	}		

});


app('process_login', function($route) { 
	// dd($route); // 'process_login'
	if (checkRoute($route)) {

		if(isValidLoginInput()) {

			$conf_data = getConfData();
			session_start();
			$_SESSION['mysess'] = $conf_data['pass_token'];
			session_regenerate_id();
			redirect('http://localhost:8000/?categories');
		}
	}
		
});


// http://localhost:8000/?categories
app('categories', function($route) {
	// dd($route); // 'categories'
	if (checkRoute($route)) {
		session_start();
		$data = [];
		$data['is_logged_in'] = isLoggedIn();
		render('templates/categories_vw', $data);
	}
});


// http://localhost:8000/?logout
app('logout', function($route) {
	if (checkRoute($route)) {
		seekAndDestroy();
		redirect('https://dir.bg');
	}
});


// ------------------------------------------ 

// http://localhost:8000/?java_data_types
app('java_installations', function($route) {
	if (checkRoute($route)) {
		session_start();
		if (isLoggedIn()) {
			renderHtml('templates/slides/slide1_vw');
		}
	}
});

// http://localhost:8000/?java_data_types
app('java_data_types', function($route) {
	if (checkRoute($route)) {
		session_start();
		if (isLoggedIn()) {
			renderHtml('templates/slides/slide2_vw');
		}
	}
});



