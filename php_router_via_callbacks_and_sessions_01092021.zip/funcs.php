
<?php
    
function getRequest() {

    $getRequest = [];
    $postRequest = [];
    $reqObj = [];

    if (isset($_GET)) {
        foreach($_GET as $key => $val) {
            $getRequest[$key] = $val;
        }
    }

    if (isset($_POST)) {
        foreach($_POST as $k => $v) {
            $postRequest[$k] = $v;
        }
    }
    
    $reqArr = [
        'get_request' => $getRequest,
        'post_request' => $postRequest
    ];

    return $reqArr;
}

function findGetParam($param_name) {
    
    $req = getRequest();
    $req = $req['get_request'];

    foreach($req as $key => $v) {
        if ($key == $param_name) {
            return ['key' => $key, 'value' => $v];
        }
    }
    return null;
}

function checkRoute($route_name) {

	$routeArr = findGetParam($route_name);
    if ($routeArr !== null) {
        if ($route_name == $routeArr['key']) {
            return true;
        }
    }
	return false;
}

function app($route = null, callable $callback) {
    $callback($route);
}

function render($tpl_path, $data = null) {
    include './templates/inc/header.php';
    include './' . $tpl_path . '.php';
    include './templates/inc/footer.php';
}

function renderHtml($tpl_path, $data = null) {
    include './templates/inc/header.php';
    include './' . $tpl_path . '.html';
    include './templates/inc/footer.php';
}

function redirect($url) {
    header("Location:" . $url);
    exit;
}

function getConfData() {
                
    $file = file_get_contents("./conf.json");
    
    $data = json_decode($file, true);
    $conf_data = [];
    $conf_data['username'] = $data['username'];
    $conf_data['password'] = $data['password'];
    $conf_data['csrf_token'] = $data['csrf_token'];
    $conf_data['pass_token'] = $data['pass_token'];
    return $conf_data;
}

function isValidLoginInput() {

    if (isset($_POST['mail']) && isset($_POST['pass'])) {	

		$conf_data = getConfData();
  
		if ($_POST['mail'] == $conf_data['username'] && 
			$_POST['pass'] == $conf_data['password']) {
                return true;
        }       
    }
    return false;
}

function isLoggedIn() {

    $conf_data = getConfData();

    if (isset($_SESSION['mysess'])) {
        if ($conf_data['pass_token'] == $_SESSION['mysess']) {
            return true;
        }
    }
    return false;
}

function seekAndDestroy() {

    $_SESSION = []; // unset all the session variables

    // If it is desired to  kill the session also delete the session cookie
    // Note: This will destroy the session, and not just the session data
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params["path"],
            $params["domain"],
            $params["secure"],
            $params["httponly"]
        );
    }

    session_destroy(); // Finally, destroy the session !

}

function escapeInput($input) {
        
    if (!empty($input)) {
        $input = trim($input);
        $input = stripslashes($input);
        $input =  htmlspecialchars($input);
        return $input;
    } 
    return null;
}

function dd($var) {
    echo '<pre>';
    print_r($var);
    echo '<pre>';
    die();
}

