<h1> I am the CATEGORIES page </h1>

<?php if ($data['is_logged_in']): ?>
    <h1> SUCCESS </h1>
    <ul>
        <li>
            <a href="?java_installations"> Java Installations</a>
        </li>  
        <li>
            <a href="?java_data_types"> Java Data Types</a>
        </li>   
    </ul>
<?php endif; ?>
