<!DOCTYPE html>
<html>
    <head>
        <style>
            .navlink {
                display: inline-block;
                margin: 4px 8px;
            }
        </style>
    </head>
    <body>
        <nav>
            <a href="http://localhost:8000/" class="navlink"> Home page </a>
            <a href="?categories" class="navlink"> Categories page </a>
            <a href="?logout" class="navlink"> Logout </a>
        </nav>